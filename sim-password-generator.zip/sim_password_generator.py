
import random
import string

def generate_password(length=8):
    # Define the characters to use for the password
    characters = string.ascii_letters + string.digits
    # Randomly choose characters from the defined set
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

if __name__ == "__main__":
    # Input from the user for password length (optional)
    password_length = int(input("Enter password length (default is 8): ") or 8)
    
    # Generate password
    password = generate_password(password_length)
    
    # Display the generated password
    print(f"Generated SIM password: {password}")
